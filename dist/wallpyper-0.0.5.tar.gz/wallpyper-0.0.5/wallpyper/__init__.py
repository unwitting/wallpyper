import wp

def get_wallpaper(): return wp.get_wallpaper()
def set_wallpaper(path): return wp.set_wallpaper(path)
